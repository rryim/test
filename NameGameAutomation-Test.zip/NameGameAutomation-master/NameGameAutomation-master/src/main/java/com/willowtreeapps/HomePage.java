package com.willowtreeapps;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created on 5/23/17.
 */
public class HomePage extends BasePage {


    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void validateTitleIsPresent() {
        WebElement title = driver.findElement(By.cssSelector("h1"));
        Assert.assertTrue(title != null);
    }


    public void validateStreak() {
        //Wait for page to load
        sleep(6000);

        int streak = Integer.parseInt(driver.findElement(By.className("streak")).getText());
        int correct = Integer.parseInt(driver.findElement(By.className("correct")).getText());

        driver.findElement(By.className("photo")).click();

        sleep(6000);

        int streakAfter = Integer.parseInt(driver.findElement(By.className("streak")).getText());
        int correctAfter = Integer.parseInt(driver.findElement(By.className("correct")).getText());

        if (correctAfter > correct) {

            Assert.assertTrue(streakAfter > streak);
        }
        else {
            Assert.assertTrue(streakAfter == 0);

        }

    }

    public void validateMultiStreak() {
        //Wait for page to load

        sleep(6000);

        int correct;
        int streakAfter;
        int correctAfter;

        do {

            correct = Integer.parseInt(driver.findElement(By.className("correct")).getText());

            driver.findElement(By.className("photo")).click();

            sleep(6000);

            streakAfter = Integer.parseInt(driver.findElement(By.className("streak")).getText());
            correctAfter = Integer.parseInt(driver.findElement(By.className("correct")).getText());
        } while (correctAfter > correct);


        Assert.assertTrue(streakAfter == 0);

    }


    public void validateClickingFirstPhotoIncreasesTriesCounter() {
        //Wait for page to load
        sleep(6000);
        int count = Integer.parseInt(driver.findElement(By.className("attempts")).getText());

        driver.findElement(By.className("photo")).click();

        sleep(6000);

        int countAfter = Integer.parseInt(driver.findElement(By.className("attempts")).getText());

        Assert.assertTrue(countAfter > count);

    }

    public void validateTenRandomSelection() {
         ;
         for (int num = 0; num < 11; num++) {

            sleep(6000);
            WebElement driver1 = driver.findElement(By.id("gallery"));
            int count = Integer.parseInt(driver.findElement(By.className("attempts")).getText());
            int correct = Integer.parseInt(driver.findElement(By.className("correct")).getText());
            driver.findElement(By.className("photo")).click();

            sleep(6000);
            this.validatePresent(By.className("photo"));
            int countAfter = Integer.parseInt(driver.findElement(By.className("attempts")).getText());
            int correctAfter = Integer.parseInt(driver.findElement(By.className("correct")).getText());

             if (correctAfter >correct) {
                Assert.assertTrue(countAfter > count);
             }
         }

    }

    public void validateNameandPhoto() {
        //Wait for page to load
        int correct;
        int correctAfter;

        do { sleep(6000);
        WebElement driver1 = driver.findElement(By.id("name"));
        WebElement driver2 = driver.findElement(By.id("gallery"));
        correct = Integer.parseInt(driver.findElement(By.className("correct")).getText());
        driver.findElement(By.className("photo")).click();
        sleep(6000);
        correctAfter = Integer.parseInt(driver.findElement(By.className("correct")).getText());
        if (correctAfter > correct) {
        Assert.assertTrue(driver1 != driver.findElement(By.id("name")));
        Assert.assertTrue(driver2 != driver.findElement(By.id("gallery")));}
        } while (correctAfter <= correct);

      }

    }


